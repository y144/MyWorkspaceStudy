package com.yangtingjia.design_ruler.jiekougeli.improvement;

/**
 * 杨廷甲
 * 2022-07-03
 */
public interface ISkillVertigo {
    //眩晕
    void doVertigo();
}
