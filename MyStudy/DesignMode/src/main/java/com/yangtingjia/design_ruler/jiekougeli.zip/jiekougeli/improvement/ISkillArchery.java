package com.yangtingjia.design_ruler.jiekougeli.improvement;

/**
 * 杨廷甲
 * 2022-07-03
 */
public interface ISkillArchery {
    //灼日之矢
    void doArchery();

}
